# Final conclusion

The division-method hash table with linear probing stores all eight song IDs successfully. With a table size of 10, the load factor is 0.8. Because the supplied IDs produce only home slots 0 and 5, collisions occur and probing is required. This illustrates that hashing performance depends on both the hash function and the distribution of keys, not merely on the use of a hash table.

For a production music application, hashing is recommended for frequent ID lookups, but the table should be resized as needed and use a hash function that distributes IDs more evenly. For this small input, linear search is simple and acceptable; for a much larger collection, a well-designed hash table is expected to provide faster average searches.
