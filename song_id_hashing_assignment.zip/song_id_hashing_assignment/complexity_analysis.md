# Complexity analysis

## Chosen implementation
- Table capacity: 10 slots.
- Hash function (division method): `h(key) = key % 10`.
- Collision resolution: linear probing.
- Stored IDs: 8.
- Load factor: `α = n/m = 8/10 = 0.8` (80%).

## Observed insertion behavior
The IDs are all multiples of 105. Their home slots alternate between 5 and 0 under modulo 10, causing collisions. Linear probing places the IDs at indices 5, 0, 6, 1, 7, 2, 8, and 3. There are 6 collisions encountered while inserting the eight IDs (counting each occupied slot encountered during probing).

## Search performance
The included search trace tests 105, 420, 840, and absent ID 999.
Hash search counts occupied slots examined before a match or stopping at an empty slot. Linear search counts array elements compared in input order. See `search_trace.csv` for exact per-query counts.

## Theoretical comparison
| Operation | Hash table (expected) | Hash table (worst case) | Linear search |
|---|---:|---:|---:|
| Search | O(1) with a good distribution and moderate load factor | O(n) | O(n) |
| Insert | O(1) expected | O(n) | O(1) to append to an unsorted list; O(n) if checking duplicates |
| Extra space | O(m) for a table of capacity m | O(m) | O(n) for stored list |

The observed load factor is high (0.8), and the hash function distributes this particular dataset poorly because the keys share a common multiple. Consequently, collisions and probe lengths are substantial, so observed hashing performance is not uniformly constant-time. Linear search is predictable but may inspect many entries.

## Conclusion
Hashing is suitable for a music application when the table is sized appropriately, a hash function spreads keys well, and the load factor is controlled (often by resizing before it becomes high). For this exact data and modulo-10 function, clustering causes many collisions. A larger table and/or a better-distributing hash function would improve performance. For only eight IDs, either method is workable; hashing becomes more beneficial for larger collections with frequent lookups.
