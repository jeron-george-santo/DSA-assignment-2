# Song ID Hashing Assignment

## Files included
- `song_hashing.c` — C implementation using division hashing and linear probing, plus linear search.
- `input_data.txt` — input IDs, hash function, and query IDs.
- `output.txt` — expected insertion and search trace.
- `insertion_trace.csv` — table state after each insertion and collision details.
- `search_trace.csv` — hashing and linear-search operations for each query.
- `complexity_analysis.md` — load factor, observed behavior, and theoretical complexity.
- `comparison_table.csv` — algorithm comparison.
- `final_conclusion.md` — conclusion and recommendation.

## Compile and run
Using GCC:
```sh
gcc song_hashing.c -o song_hashing
./song_hashing
```
On Windows with MinGW:
```bat
gcc song_hashing.c -o song_hashing.exe
song_hashing.exe
```

## Design choices
The assignment screenshot does not specify table size or collision resolution. This solution explicitly uses a 10-slot table, `h(key) = key % 10`, and linear probing so collisions can be traced and compared fairly. Search targets are 105, 420, 840, and 999 (an absent ID).
