#include <stdio.h>
#define TABLE_SIZE 10
#define N 8

int hashTable[TABLE_SIZE];

void initialize(void) {
    for (int i = 0; i < TABLE_SIZE; i++) hashTable[i] = -1;
}

int hashFunction(int key) {
    return key % TABLE_SIZE;
}

int insertKey(int key) {
    int index = hashFunction(key);
    int start = index;
    while (hashTable[index] != -1) {
        printf("Collision for %d at index %d; probing next slot.\n", key, index);
        index = (index + 1) % TABLE_SIZE;
        if (index == start) {
            printf("Table is full; cannot insert %d.\n", key);
            return 0;
        }
    }
    hashTable[index] = key;
    printf("Inserted %d: hash index %d, final index %d\n", key, hashFunction(key), index);
    return 1;
}

int hashSearch(int key, int *operations) {
    int index = hashFunction(key);
    int checked = 0;
    *operations = 0;
    while (checked < TABLE_SIZE && hashTable[index] != -1) {
        (*operations)++;
        if (hashTable[index] == key) return index;
        index = (index + 1) % TABLE_SIZE;
        checked++;
    }
    return -1;
}

int linearSearch(const int arr[], int n, int key, int *comparisons) {
    *comparisons = 0;
    for (int i = 0; i < n; i++) {
        (*comparisons)++;
        if (arr[i] == key) return i;
    }
    return -1;
}

int main(void) {
    int songIDs[N] = {105, 210, 315, 420, 525, 630, 735, 840};
    int queries[] = {105, 420, 840, 999};
    int queryCount = sizeof(queries) / sizeof(queries[0]);
    initialize();

    printf("Insertion trace (division method, linear probing; table size = %d):\n", TABLE_SIZE);
    for (int i = 0; i < N; i++) insertKey(songIDs[i]);

    printf("\nFinal hash table:\n");
    for (int i = 0; i < TABLE_SIZE; i++)
        printf("Index %d: %s%d\n", i, hashTable[i] == -1 ? "empty " : "", hashTable[i] == -1 ? 0 : hashTable[i]);

    printf("\nSearch comparison:\n");
    printf("Target\tHash result\tHash operations\tLinear result\tLinear comparisons\n");
    for (int i = 0; i < queryCount; i++) {
        int hashOps, linearOps;
        int h = hashSearch(queries[i], &hashOps);
        int l = linearSearch(songIDs, N, queries[i], &linearOps);
        printf("%d\t%s\t\t%d\t\t%s\t\t%d\n", queries[i],
               h >= 0 ? "Found" : "Not found", hashOps,
               l >= 0 ? "Found" : "Not found", linearOps);
    }
    return 0;
}
